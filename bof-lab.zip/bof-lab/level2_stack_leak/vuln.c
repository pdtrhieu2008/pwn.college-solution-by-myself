// =========================================================
//  BOF LAB - LEVEL 2: Stack Leak -> Vuot ASLR -> ret2shellcode
//
//  Boi canh: khong con ham win() co san. ASLR bat (dia chi
//  stack ngau nhien moi lan chay). Chuong trinh co MOT tinh
//  nang "debug" vo tinh lam ro ri dia chi cua buffer tren
//  stack (day la mo hinh hoa mot loi ro ri thong tin thuong
//  gap trong thuc te: format string bug, thong bao debug,
//  log qua chi tiet, v.v.)
//
//  Muc tieu: dung dia chi ro ri de biet CHINH XAC buffer
//  nam o dau tren stack (vi ASLR doi moi lan chay), chen
//  shellcode vao buffer, roi ghi de return address bang
//  chinh dia chi da leak de nhay vao va thuc thi shellcode.
// =========================================================
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

void leak_info() {
    char probe[16];
    // LO HONG RO RI THONG TIN: chuong trinh vo tinh in ra dia chi
    // stack cua bien cuc bo -> ke tan cong dung no de tinh ra
    // dia chi cua buffer trong ham vuln() (lech mot khoang co dinh).
    printf("[debug] &probe = %p\n", (void*)probe);
}

void vuln() {
    char buffer[128];

    printf("Nhap shellcode/du lieu cua ban: ");
    fflush(stdout);

    // LO HONG BOF: doc toi 300 byte vao buffer 128 byte.
    read(0, buffer, 300);
}

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);

    printf("=== BOF Lab - Level 2: Stack Leak + ret2shellcode ===\n");

    leak_info();   // vo tinh ro ri dia chi stack
    vuln();        // dinh tran bo dem

    printf("Chuong trinh ket thuc binh thuong.\n");
    return 0;
}
