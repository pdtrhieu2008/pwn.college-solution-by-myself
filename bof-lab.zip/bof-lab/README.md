# BOF Lab — Buffer Overflow & Stack Leak

Lab tự học khai thác lỗ hổng tràn bộ đệm (stack-based buffer overflow)
và kỹ thuật rò rỉ địa chỉ (stack leak) để vượt ASLR. Toàn bộ chương
trình trong lab là **binary tự viết, tự biên dịch, chạy trên máy của
bạn** — không nhắm vào phần mềm/hệ thống thật của ai khác. Đây là mô
hình bài học kiểu CTF pwn (tương tự SEED Labs, pwn.college, Modern
Binary Exploitation...).

```
bof-lab/
├── level1_ret2win/       # Level 1: BOF cơ bản, ghi đè return address -> nhảy vào hàm có sẵn
│   ├── vuln.c
│   ├── Makefile
│   └── exploit.py
├── level2_stack_leak/    # Level 2: BOF + rò rỉ địa chỉ stack -> vượt ASLR -> chạy shellcode
│   ├── vuln.c
│   ├── Makefile
│   └── exploit.py
└── README.md
```

---

## 0. Chuẩn bị môi trường

Khuyến khích chạy trên **Linux** (Ubuntu/Debian là tiện nhất). Cài:

```bash
sudo apt update
sudo apt install -y build-essential gdb gcc python3 python3-pip
pip3 install --break-system-packages pwntools
```

Tuỳ chọn nhưng rất nên có — plugin gdb giúp xem stack/heap trực quan:

```bash
# GEF (khuyên dùng, dễ cài nhất)
bash -c "$(curl -fsSL https://gef.blah.cat/sh)"
```

Kiểm tra bảo vệ nhị phân của một file bằng `pwntools`:

```bash
python3 -c "from pwn import *; print(ELF('./vuln'))"
```

---

## 1. Kiến thức nền cần nắm trước

**Stack frame (x86-64, quy ước gcc mặc định khi có `push %rbp; mov %rsp,%rbp`):**

```
địa chỉ cao
┌────────────────────────┐
│  tham số thứ 7+ (nếu có)│
├────────────────────────┤
│  return address (8B)   │  <- lệnh `ret` sẽ nhảy tới đây
├────────────────────────┤
│  saved RBP (8B)        │  <- lệnh `leave` khôi phục lại
├────────────────────────┤
│  local variables        │  <- buffer[] nằm ở đây, TRÀN XUỐNG
│  (buffer, ...)          │     sẽ ghi đè các ô phía trên
└────────────────────────┘
địa chỉ thấp   (stack "lớn dần xuống")
```

Khi hàm có `char buffer[64]` và code đọc dữ liệu vào `buffer` **nhiều
hơn 64 byte** mà không kiểm tra độ dài, dữ liệu dư sẽ tràn tuần tự lên
`saved RBP` rồi tới `return address`. Kiểm soát được các byte nằm ở vị
trí `return address` = kiểm soát được nơi CPU sẽ nhảy tới tiếp theo.

**Các cơ chế bảo vệ liên quan (bạn sẽ tắt một số cái để tập trung vào
kỹ thuật, rồi có thể tự bật lại để luyện bypass nâng cao):**

| Bảo vệ | Vai trò | Trong lab này |
|---|---|---|
| Stack canary | Giá trị ngẫu nhiên đặt trước return address, kiểm tra trước khi `ret`, phát hiện overflow | **Tắt** (`-fno-stack-protector`) để tập trung học BOF thuần |
| NX (No-eXecute) | Đánh dấu vùng stack không cho thực thi code | Level 1: **bật** (không cần, dùng ret2win). Level 2: **tắt** để minh hoạ ret2shellcode |
| PIE / ASLR | Ngẫu nhiên hoá địa chỉ nạp code/stack mỗi lần chạy | Level 1: **tắt PIE** (địa chỉ hàm cố định). Level 2: **ASLR mặc định bật cho stack** — đây chính là lý do cần "leak" |
| CET (Shadow Stack) | CPU đời mới lưu bản sao return address ở vùng riêng, chặn ghi đè return address cổ điển | **Tắt** (`-fcf-protection=none`) vì lab dạy kỹ thuật cổ điển; SHSTK là chủ đề nâng cao khác |

---

## 2. Level 1 — `ret2win` (BOF cơ bản)

**File:** `level1_ret2win/vuln.c`

Chương trình có hàm `win()` không bao giờ được gọi trong luồng bình
thường. Bạn cần tràn bộ đệm để ghi đè return address bằng địa chỉ của
`win()`.

### Build

```bash
cd level1_ret2win
make
```

### Bước 1 — Tìm offset tới return address

Cách thủ công, tự làm (khuyến khích làm trước khi xem đáp án):

```bash
# Sinh chuỗi "cyclic" duy nhất từng đoạn 4 byte để dễ tra ngược
python3 -c "from pwn import *; print(cyclic(200))" > /tmp/pattern.txt

gdb ./vuln
(gdb) run < /tmp/pattern.txt
# Chương trình crash, xem lệnh dừng ở đâu / RBP hỏng ra sao
(gdb) info registers rbp
# Copy giá trị đó rồi:
(gdb) python from pwn import cyclic_find; print(cyclic_find(0x<gia_tri_rbp>))
```

Hoặc đọc trực tiếp bằng `objdump -d ./vuln` để xem `sub $0x.., %rsp`
(kích thước khung stack) rồi cộng thêm 8 byte (saved RBP) — chính là
cách file `exploit.py` đã làm và đã kiểm chứng: **offset = 72 byte**.

### Bước 2 — Lấy địa chỉ `win()`

```bash
python3 -c "from pwn import *; print(hex(ELF('./vuln').symbols['win']))"
# hoặc: objdump -d ./vuln | grep '<win>:'
```

### Bước 3 — Chạy exploit

```bash
python3 exploit.py
```

Payload = `b'A' * 72 + p64(địa_chỉ_win)`. Khi `vuln()` return, CPU
nhảy vào `win()` → `win()` gọi `system("/bin/sh")` → bạn có shell.
(Đã kiểm thử thực tế: lệnh `id` trong shell trả về `uid=0(root)...`.)

---

## 3. Level 2 — Stack Leak vượt ASLR + `ret2shellcode`

**File:** `level2_stack_leak/vuln.c`

Lần này **không có hàm `win()`** để nhảy tới. Thay vào đó bạn phải tự
đưa shellcode vào và nhảy chính xác vào nó. Vấn đề: địa chỉ stack bị
ASLR làm ngẫu nhiên mỗi lần chạy, nên không thể "đoán cứng" một địa
chỉ. Chương trình có hàm `leak_info()` vô tình in ra địa chỉ một biến
cục bộ (`&probe`) — đây là mô hình hoá một **lỗi rò rỉ thông tin**
(thực tế thường đến từ format-string bug, log/debug quá chi tiết,
thông báo lỗi in luôn con trỏ...).

### Build

```bash
cd level2_stack_leak
make
```

### Ý tưởng khai thác — 4 bước

1. **Đọc địa chỉ bị leak**: chương trình tự in `&probe`.
2. **Tính địa chỉ `buffer`** trong `vuln()` từ địa chỉ đã leak, dựa
   trên độ lệch cố định giữa 2 khung stack (đọc bằng `objdump -d`,
   xem trong `exploit.py`): `buffer = probe - 0x70`.
3. **Nhồi shellcode** (`shellcraft.sh()` của pwntools sinh sẵn shellcode
   `execve("/bin/sh")`) vào đầu `buffer`.
4. **Ghi đè return address = địa chỉ `buffer` vừa tính** (offset tới
   return address = `128 (buffer) + 8 (saved rbp) = 136` byte). Khi
   `vuln()` return, CPU nhảy thẳng vào buffer và thực thi shellcode.

### Chạy

```bash
python3 exploit.py
```

Đã kiểm thử thực tế: script tự đọc dòng `[debug] &probe = 0x...`, tính
ra địa chỉ buffer, gửi payload, và `id` trong shell trả về
`uid=0(root)...` — chứng minh đã điều khiển RIP nhảy đúng vào
shellcode tự chèn, bất chấp ASLR đổi địa chỉ mỗi lần chạy.

### Tự làm lại bằng gdb (không nhìn script)

```bash
gdb ./vuln
(gdb) break *vuln+0   # hoặc break vuln
(gdb) run
(gdb) print &probe     # xem trong leak_info, hoặc dùng 'x/g $rbp-0x10'
(gdb) x/20xg $rsp      # quan sát bố cục stack sau khi nhập payload thử
```

So sánh địa chỉ in ra bởi chương trình với địa chỉ `buffer` bạn tự
tính bằng `p &buffer` trong `vuln()` để kiểm chứng công thức offset.

---

## 4. Bài tập mở rộng (tự nâng độ khó)

Khi đã nắm chắc 2 level trên, hãy tự tăng độ khó để hiểu vì sao các
lớp bảo vệ hiện đại tồn tại:

- **Bật lại stack canary** (bỏ `-fno-stack-protector`): quan sát
  chương trình bị `abort()` khi bạn overflow — tìm hiểu vì sao cần một
  lỗ rò rỉ *canary* riêng (thường qua leak 1 byte cuối vì canary luôn
  kết thúc bằng `0x00`) trước khi ghi đè return address.
- **Bật NX** cho Level 2 (bỏ `-z execstack`): shellcode trên stack sẽ
  không chạy được nữa → buộc phải học **ROP (Return-Oriented
  Programming)** — dùng các đoạn code có sẵn trong binary/libc thay vì
  tự chèn code.
- **Bật PIE** cho cả 2 level: toàn bộ địa chỉ hàm cũng bị ASLR hoá →
  phải kết hợp leak địa chỉ code (không chỉ leak stack) để tính base
  address thật của binary.
- Thử tấn công qua **format string bug** thay vì `read()` tràn thẳng,
  để tự tạo ra chính "tính năng debug rò rỉ địa chỉ" thay vì được cho
  sẵn như ở Level 2.

## 5. Phạm vi & lưu ý

Lab này chỉ nhằm dạy **cơ chế** khai thác bộ nhớ ở mức nền tảng trên
các chương trình mẫu tự chứa, tự biên dịch. Áp dụng các kỹ thuật này
để tấn công hệ thống/phần mềm của người khác mà không được phép là vi
phạm pháp luật — chỉ thực hành trên máy/binary do chính bạn tạo ra
hoặc trong các nền tảng CTF hợp pháp (pwn.college, picoCTF, HackTheBox,
CTFtime...).
