// =========================================================
//  BOF LAB - LEVEL 1: ret2win (Buffer Overflow co ban)
//  Muc tieu: ghi de dia chi tra ve tren stack de nhay vao
//            ham win() ma luong thuc thi binh thuong khong
//            bao gio goi toi.
// =========================================================
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

// Ham "bi mat" - khong duoc goi o dau ca trong main().
// Nhiem vu cua ban: dieu khien RIP nhay toi day.
void win() {
    printf("\n[+] Chuc mung! Ban da chiem quyen dieu khien luong thuc thi.\n");
    printf("[+] EIP/RIP da nhay toi win() thanh cong.\n");
    system("/bin/sh");
}

void vuln() {
    char buffer[64];

    printf("Nhap du lieu cua ban: ");
    fflush(stdout);

    // LO HONG: doc toi 256 byte vao buffer chi co 64 byte
    // -> tran bo dem tren stack, co the ghi de saved RBP
    //    va saved return address.
    read(0, buffer, 256);

    printf("Ban vua nhap: %s\n", buffer);
}

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    setvbuf(stdin, NULL, _IONBF, 0);

    printf("=== BOF Lab - Level 1: ret2win ===\n");
    printf("Dia chi ham win(): %p (chi hien de ban doi chieu, thuc te khi\n", (void*)win);
    printf("khai thac 1 binary that ban se phai tu tim bang objdump/gdb)\n\n");

    vuln();

    printf("Chuong trinh ket thuc binh thuong (ban chua khai thac duoc).\n");
    return 0;
}
